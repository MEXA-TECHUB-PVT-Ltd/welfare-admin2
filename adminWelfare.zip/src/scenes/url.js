// const url = 'http://64.227.101.127/';
// const url = 'http://localhost:4000/';
const url = 'http://localhost:4000/';


// http://146.190.228.254/
// http://localhost:4000/
export default url;