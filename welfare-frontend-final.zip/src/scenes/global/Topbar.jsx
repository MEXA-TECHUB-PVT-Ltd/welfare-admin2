import React,{ useState ,useEffect} from "react";
import { Box, IconButton, useTheme } from "@mui/material";
import { useContext } from "react";
import { ColorModeContext, tokens } from "../../theme";
import InputBase from "@mui/material/InputBase";
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import NotificationsOutlinedIcon from "@mui/icons-material/NotificationsOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import PersonOutlinedIcon from "@mui/icons-material/PersonOutlined";
import SearchIcon from "@mui/icons-material/Search";
import Typography from '@mui/material/Typography';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Link from '@mui/material/Link';
import HomeIcon from '@mui/icons-material/Home';
import LogoutIcon from '@mui/icons-material/Logout';
import { useNavigate } from 'react-router-dom';
import Tooltip from '@mui/material/Tooltip';

const Topbar = () => {
  const navigate = useNavigate();
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const colorMode = useContext(ColorModeContext);
// BreadCrumb 
// const [items, setItems] = useState([]);

//   useEffect(() => {
//     const items = JSON.parse(localStorage.getItem('breadcrumb'));
//     console.log(items)
//     if (items==null) {
    
//     // navigate('/authentication/sign-in')


//     }else{
//       setItems(items);
//       console.log("items")
//       console.log(items)
//       // navigate('/dashboard')
//     }
//   }, []);
  return (
    <>
      <Box display="flex" justifyContent="space-between" p={2} style={{ borderBottom: '1px solid #adadad' }}>
        {/* SEARCH BAR */}
        <Box
          display="flex"
          backgroundColor={colors.primary[400]}
          borderRadius="3px"
        >
          {/* <InputBase sx={{ ml: 2, flex: 1 }} placeholder="Search" /> */}
          {/* <IconButton type="button" sx={{ p: 1 }}>
            <SearchIcon />
          </IconButton> */}
        </Box>

        {/* ICONS */}
        <Box display="flex">
        <Tooltip title="Theme">
          <IconButton onClick={colorMode.toggleColorMode}>
            {theme.palette.mode === "dark" ? (
              <DarkModeOutlinedIcon />
            ) : (
              <LightModeOutlinedIcon />
            )}
          </IconButton>
          </Tooltip>
          {/* <IconButton>
            <NotificationsOutlinedIcon />
          </IconButton> */}
           <Tooltip title="Logout">
           <IconButton   onClick={() => {
          localStorage.removeItem('items');
          // setIsLoggedin(false);
         navigate('/')
        
       }}>
            <LogoutIcon />
          </IconButton>
           </Tooltip>
         
          {/* <IconButton>
            <PersonOutlinedIcon />
          </IconButton> */}
        </Box>
      </Box>
      {/* <Box display="flex" justifyContent="space-between" p={2} style={{ borderBottom: '1px solid #adadad' }}>
        <Breadcrumbs aria-label="breadcrumb">
          <Link underline="hover" color="inherit" href="/">
            <HomeIcon />
          </Link>

          <Typography color="text.primary">Breadcrumb</Typography>
        </Breadcrumbs>
        <Box display="flex">
        
         
        </Box>
      </Box> */}
    </>
  );
};

export default Topbar;
